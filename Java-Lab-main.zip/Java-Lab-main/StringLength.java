

public class StringLength
{
	public static void main(String[] args) {
	    //create a string
	    String greet  = "Hello! World";
		System.out.println("String : "+ greet);
		
	  // get lenght of String
	  int length = greet.length();
		System.out.println("lenght = " + length);
	}
}
