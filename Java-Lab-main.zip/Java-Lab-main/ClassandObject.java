//Demonstrate creating a class and Instance(object)

public class ClassandObject {
    int x=5;
    public static void main(String[] args) {
        ClassandObject obj=new ClassandObject();
        System.out.print(obj.x);
    }

}
