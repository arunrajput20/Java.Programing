public class MultiThreadingDemo implements Runnable{
    public void run(){
        try {
            System.out.println("thread" + Thread.currentThread().getId() + " is running By Java");
        }
        catch(Exception e)
            {
                System.out.println(" Exception is caught here");
            }
        }
    }
    class MultiThread {
        public static void main(String[]args)
        {
            int n=8;
            for(int i= 0;i<n;i++){
                Thread Object = new Thread(new MultiThreadingDemo());
                object.start();
            }
        }
    }
