import java.util.Scanner;
public class TwoDimensionarrayEx3{

	public static void main(String[] args) {
	    Scanner sc =new Scanner(System.in);
	    //System.out.println("Enter row of array : ");
	    //int n = sc.nextInt();
	    // System.out.println("Enter column of array : ");
	   // int m = sc.nextInt();
	    String[][] arr={{"Mr.","Mrs.","Ms."},{"Kumar"}};
	    System.out.println(arr[0][0] + arr[1][0]);
	    System.out.println(arr[0][1] + arr[1][0]);
	    System.out.println(arr[0][2] + arr[1][0]);
	}
}
