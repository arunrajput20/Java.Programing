public class Main extends Thread
{
    public void run()
    {
        System.out.println("Welcome to CSIT");
    }
    public static void main(String[]args)
    {
        Thread n1 = new Thread(t1);
        Thread n2 = new Thread(t2);
        Thread n3 = new Thread(t3);
        n1.start();
        n2.start();
        n3.start();
    }
}