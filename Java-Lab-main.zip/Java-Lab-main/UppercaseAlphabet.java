//Write  a program in java to Display uppercased alphabet A to Z using for loop

public class UppercaseAlphabet {
    public static void main(String[] args) {
        
        for (char letter = 'A'; letter <= 'Z'; letter++) {
            System.out.print(letter + " ");
        }
    }
}

