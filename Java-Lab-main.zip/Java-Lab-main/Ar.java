public class Ar
{
	public static void main(String[] args) {
		//int arr[] = new int[3];
		int arr[] = new int[]{1,2,3,4}; 
	}
}
