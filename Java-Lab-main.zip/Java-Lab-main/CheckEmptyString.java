
//to check wether the string is empty or not

public class CheckEmptyString
{
	public static void main(String[] args) {
	    //create a string
	    String greet  = "Hello! World";
		System.out.println("String : "+ greet);
		
	  // Check empty String
	  boolean b = greet.isEmpty();
		System.out.println(b);
		System.out.println(greet.isEmpty());
	}
}
