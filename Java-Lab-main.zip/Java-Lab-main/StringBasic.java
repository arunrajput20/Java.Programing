

public class StringBasic
{
	public static void main(String[] args) {
	    String first = "Java";
	    String s = new String("Python");
	    String third = "Javascipt";
		System.out.println(first);
		System.out.println(s);
		System.out.println(third);
	}
}
